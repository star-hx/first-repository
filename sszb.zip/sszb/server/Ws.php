<?php

class Ws {

    public $serv = '';
    public function __construct(){
        $this->serv = new swoole_websocket_server('0.0.0.0', 9502);

        $this->serv->set([
            'enable_static_handler' => true,
            'document_root' => '/vagrant_data/sszb/public/static',
            'worker_num' => 1,
            'task_worker_num' => 1,
        ]);

        $this->serv->on('open',[$this, 'onOpen']);
        $this->serv->on('message',[$this, 'onMessage']);
        $this->serv->on('workerStart',[$this, 'onWorkerStart']);
        $this->serv->on('task',[$this, 'onTask']);
        $this->serv->on('finish',[$this, 'onFinish']);
        $this->serv->on('request',[$this, 'onRequest']);
        $this->serv->on('close',[$this, 'onClose']);

        $this->serv->start();
    }

    public function onOpen($ws, $requese) {
        try {
            //异步任务分发。
            $ret = \app\index\util\ProcessTask::pushLiveFd($requese->fd);
            dump($requese->fd. ' process ret is : '. $ret);
        } catch (Exception $e) {
            echo 'Exception-------------------' . $e->getMessage();
        }
    }

    public function onMessage($ws, $frame) {

    }

    public function onWorkerStart(swoole_server $server, $worder_id) {
        // 定义应用目录
        define('APP_PATH', __DIR__ . '/../application/');
        require __DIR__ . '/../thinkphp/start.php';
    }


    public function onTask(swoole_server $serv, $task_id, $src_worker_id, $taskData) {
        try {
            //异步任务分发。
            $ret = call_user_func_array(array('\app\index\util\ProcessTask', $taskData['method']) , $taskData['data'] );
        } catch (Exception $e) {
            echo 'Exception-------------------' . $e->getMessage();
        }
    }


    public function onFinish() {

    }


    public function onRequest( $request, swoole_http_response $response) {
        if (!empty($_SERVER)) {
            unset($_SERVER);
        }
        if (isset($request->server)) {
            foreach ($request->server as $key => $value) {
                $_SERVER[strtoupper($key)] = $value;
            }
        }
        if (!empty($_FILES)) {
            unset($_FILES);
        }
        if (isset($request->files)) {
            foreach ($request->server as $key => $value) {
                $_FILES[strtoupper($key)] = $value;
            }
        }
        if (isset($request->header)) {
            foreach ($request->header as $key => $value) {
                $_SERVER[strtoupper($key)] = $value;
            }
        }
        if (!empty($_GET)) {
            unset($_GET);
        }
        if (isset($request->get)) {
            foreach ($request->get as $key => $value) {
                $_GET[($key)] = $value;
            }
        }
        if (!empty($_POST)) {
            unset($_POST);
        }
        if (isset($request->post)) {
            foreach ($request->post as $key => $value) {
                $_POST[($key)] = $value;
            }
        }
        $_POST['http_server'] = $this->serv;
        ob_start();
//    // 2. 执行应用
        try{
            \think\Container::get('app', [defined('APP_PATH') ? APP_PATH : ''])
                ->run()
                ->send();
        }catch (\Exception $e) {
            echo $e->getMessage();
        }
        $res = ob_get_contents();
        $response->end($res);

        $this->serv->close($request->fd);
    }


    public function onClose($ser, $fd) {
        try {
            $ret = \app\index\util\ProcessTask::delLiveFd($fd);
            dump('onClose '. $fd . ' process ret is : '. $ret . '\n');
        } catch (Exception $e) {
            echo 'Exception-------------------' . $e->getMessage();
        }
    }

}

new Ws();