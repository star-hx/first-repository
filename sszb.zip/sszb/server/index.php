<?php

class index {
    public function hello() {
        return '123'."<br>";
    }
}