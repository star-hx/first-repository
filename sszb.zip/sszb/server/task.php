<?php
//创建Server对象，监听 127.0.0.1:9501端口
$serv = new swoole_http_server('0.0.0.0', 9502);

$serv->set([
    'enable_static_handler' => true,
    'document_root' => '/vagrant_data/sszb/public/static',
    'worker_num' => 1,
    'task_worker_num' => 1,
]);


$serv->on('WorkerStart', function (swoole_server $server, $worder_id) use ($serv){

    // 定义应用目录
    define('APP_PATH', __DIR__ . '/../application/');

    require __DIR__ . '/../thinkphp/base.php';
});

$serv->on('task', function (swoole_server $serv, $task_id, $src_worker_id, $data){
    $file = $data['file'];
    require_once $file;
    $obj = new index();
    var_dump($obj->hello());
});

$serv->on('Finish', function (){

});

$serv->on('request', function ( $request, swoole_http_response $response) use ($serv) {
    $_GET = $request->get;
    if (isset($_GET['needReload'])){
        $serv->reload();
        return ;
    }
    $serv->task([
        'file' => 'index.php',
    ]);

    ob_start();
//    // 2. 执行应用
    try{
        \think\Container::get('app', [defined('APP_PATH') ? APP_PATH : ''])
            ->run()
            ->send();
    }catch (\Exception $e) {
        echo $e->getMessage();
    }
    $res = ob_get_contents();
    $response->end($res);

    $serv->close($request->fd);

});



$serv->start();