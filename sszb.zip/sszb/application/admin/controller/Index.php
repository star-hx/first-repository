<?php
namespace app\admin\controller;

use app\index\util\ProcessTask;
use app\index\util\Redis;
use think\CommonTool;

class Index
{

    public $wsSer;

    public function __construct(){
        $this->wsSer = $_POST['http_server'];
    }

    public function save(){
        $ret = [];
        $pushData['content'] = $_POST['content'];
        $pushData['team'] = $_POST['team_id'] == 1 ? '马刺' : '火箭';
        $pushData['timer'] = $_POST['timer'];
        $fds = ProcessTask::getLiveFds();

        foreach ($fds as $fd) {
            $ret[] = $this->wsSer->push($fd, json_encode($pushData));
        }
        dump($ret);

    }

}
