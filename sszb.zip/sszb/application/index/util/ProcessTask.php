<?php
namespace app\index\util;

class ProcessTask {

    public static function sendMsg($phone, $code) {
        $obj = new Sms();
        return $obj->sendMsg($phone, $code);
    }

    public static function pushLiveFd($fd) {
        $redisObj = Redis::getRedisObj();
        return $redisObj->hSet('live', $fd, 1);
    }

    public static function delLiveFd($fd) {
        $redisObj = Redis::getRedisObj();
        return $redisObj->hDel('live', $fd);
    }

    public static function getLiveFds(){
        $redisObj = Redis::getRedisObj();
        return $redisObj->hKeys('live');
    }
}
