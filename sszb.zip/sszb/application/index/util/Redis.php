<?php
namespace app\index\util;

class Redis {
    private $host = '127.0.0.1';
    private $post = '6379';
    private $timerOut = '30';

    private static $_redisObj = null;

    public static function getRedisObj(){
        if (is_null(self::$_redisObj)) {
            new self();
        }
        return self::$_redisObj;
    }

    private function __construct() {
        $obj = new \Redis();
        $obj->connect($this->host, $this->post,  $this->timerOut);
        self::$_redisObj = $obj;
    }

    public function set($key, $value, $timerOut = 30) {
        if (empty($key)) {
            return '';
        }

        if (empty($timerOut)) {
            self::$_redisObj->set($key, json_encode($value));
        }

        self::$_redisObj->setex($key, $timerOut, json_encode($value));
    }

    public function get($key) {
        if (empty($key)) {
            return '';
        }

        return json_decode(self::$_redisObj->get($key));
    }
}
