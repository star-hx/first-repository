<?php
namespace app\index\util;

class CommonTool {
    public static function isSuccessRet($ret) {
        return $ret['result'] == 'success';
    }

    public static function isFailRet($ret) {
        return $ret['result'] == 'fail';
    }

    public static function failResult($reason) {
        return array (
            'result' => 'fail',
            'reason' => $reason
        );
    }

    public static function successResult() {
        return array (
            'result' => 'success',
        );
    }
}
