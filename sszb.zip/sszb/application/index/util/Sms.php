<?php
namespace app\index\util;

class Sms {
    public function __construct(){

    }

    public function sendMsg($phone, $code) {
        $obj = Redis::getRedisObj();
        return $obj->set($phone, $code);
    }
}
