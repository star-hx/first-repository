<?php
namespace app\index\controller;

class Login
{
    public function index()
    {
        echo 123123;
    }

    public function login() {
        echo 'success';
    }

}
