<?php
namespace app\index\controller;

use app\index\util\Redis;
use think\CommonTool;

class Index
{
    public function index()
    {
//        $obj = Redis::getRedisObj();
//        $obj->set('hx', 'haha', '1');
//        echo $obj->get('hx');
    }

    public function sendMsg() {
        $httpServer = $_POST['http_server'];
        $taskData = [
            'method' => 'sendMsg',
            'data' => [
                'phone' => 17610707211,
                'code' => rand(1000, 9999)
            ]
        ];
        $httpServer->task($taskData);
        dump($taskData);
    }

    public function getMsg() {
        $obj = Redis::getRedisObj();
        echo  $obj->get('1761070721');
    }

}
